package com.greenapple.endpoint;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

public class test {
	// Find your Account Sid and Token at twilio.com/console
	// DANGER! This is insecure. See http://twil.io/secure
	public static final String ACCOUNT_SID = "ACb7edce0567e980cb2c6519adc7f318ab";
	public static final String AUTH_TOKEN = "e944e47ac5c96c6a1e29ac3d259ddca8";

	public static void main(String[] args) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		Message message = Message.creator(new com.twilio.type.PhoneNumber("whatsapp:+919810966244"),
				new com.twilio.type.PhoneNumber("whatsapp:+14155238886"), "Hello there!").create();

		System.out.println(message.getSid());
	}
}
