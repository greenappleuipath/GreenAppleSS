package com.greenapple.endpoint;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.greenapple.entity.StudentDetail;
import com.greenapple.repository.StudentDetailRepository;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

@Controller
@RequestMapping("/GreenApple")
public class SchoolAdmissionEndpoint {

	@Autowired
	private StudentDetailRepository studentRepo;
	

	@Autowired
	private AmazonSNS amazonSNS;
	
	@PostMapping
	public @ResponseBody JsonNode saveAdmissionFormDetail(@RequestBody Map<String, Object> request) throws IOException {
		
		System.out.println(request);
		StudentDetail studentDetail = new StudentDetail();
		List<Map<String,Object>> list = (List<Map<String,Object>>) ((Map<String,Map>)request.get("queryResult")).get("outputContexts");
		
		list.forEach(a ->{
			if(((String)((Map<String,Object>)a).get("name")).contains("studentdetails")) {
				Map<String,Object> map = (Map<String,Object>)((Map<String,Object>)a).get("parameters");
				System.out.println(map);
				studentDetail.setStudentName(map.get("studentName").toString());

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date convertedCurrentDate;
				try {
					convertedCurrentDate = sdf.parse(map.get("studentDob").toString().split("T")[0]);
				} catch (ParseException e) {
					convertedCurrentDate = null;
					e.printStackTrace();
				}
				
				studentDetail.setStudentDOB(convertedCurrentDate);
				
				studentDetail.setFatherName(map.get("fatherName").toString());
				
				studentDetail.setMotherName(map.get("motherName").toString());
				
				studentDetail.setPhone(map.get("phoneNumber").toString());
				
				studentDetail.setStatus("Pending");
				
				studentDetail.setIds("1234");
			}
			
		});
		
		
		studentRepo.save(studentDetail);
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readTree("{\r\n" + 
				"  \"payload\": {\r\n" + 
				"    \"google\": {\r\n" + 
				"      \"expectUserResponse\": false,\r\n" + 
				"      \"richResponse\": {\r\n" + 
				"        \"items\": [\r\n" + 
				"          {\r\n" + 
				"            \"simpleResponse\": {\r\n" + 
				"              \"textToSpeech\": \"You'll receive the email shortly with all the submitted application form, Goodbye!\"\r\n" + 
				"            }\r\n" + 
				"          }\r\n" + 
				"        ]\r\n" + 
				"      }\r\n" + 
				"    }\r\n" + 
				"  }\r\n" + 
				"}");
		
		
		 
		
		return actualObj;
	}
	
	
	@GetMapping(path="/callAttendent/{phoneNum}")
	public @ResponseBody String sendSMS(@PathVariable String phoneNum) {
		
		try {
        amazonSNS.publish(new PublishRequest()
        .withMessage("Please attend the BOT")
        .withPhoneNumber("+91"+phoneNum)
        .withMessageAttributes(new HashMap<String, MessageAttributeValue>()));
		}catch(Exception e) {
			
		}
		return "Message Sent";
	}
	

	public static final String ACCOUNT_SID = "ACb7edce0567e980cb2c6519adc7f318ab";
	public static final String AUTH_TOKEN = "e944e47ac5c96c6a1e29ac3d259ddca8";
	
	@GetMapping(path="/sendWhatsApp/{phoneNumber}")
	public @ResponseBody String sendWhatsApp(@PathVariable String phoneNumber) {

		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		Message message = Message.creator(new com.twilio.type.PhoneNumber("whatsapp:+91"+phoneNumber),
				new com.twilio.type.PhoneNumber("whatsapp:+14155238886"), "Hello Parents! your school application form submitted.").create();

		System.out.println(message.getSid());

		return "Message Sent";
	}
	
	@PostMapping(path="/twilio")
	public @ResponseBody String sendSMS() {

		return "Message Sent";
	}
	
}
